// Production API base URL (used only by `ng build --configuration production`,
// swapped in for ./index.ts through "fileReplacements" in angular.json).
// Local development (`ng serve`) still uses http://localhost:5000/ from ./index.ts.
//
// BEFORE DEPLOYING: replace the value below with the public URL of your hosted
// Express/MongoDB backend. Keep the trailing slash, e.g. 'https://tedbus-api.onrender.com/'
export const url:string='https://YOUR-BACKEND-URL/';
